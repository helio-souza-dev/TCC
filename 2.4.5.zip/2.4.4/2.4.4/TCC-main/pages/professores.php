<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// ------------------------------
// VARIÁVEIS DE CONTROLE
// ------------------------------
$message = '';
$error = '';

// ------------------------------
// FUNÇÕES DE VALIDAÇÃO
// ------------------------------
function validarIdade(string $data_nascimento, int $idade_minima = 17): bool
{
    $dataNasc = new DateTime($data_nascimento);
    $hoje = new DateTime();
    $idade = $hoje->diff($dataNasc)->y;
    return $idade >= $idade_minima;
}

function validarCPF(string $cpf): bool
{
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11) return false;
    if (preg_match('/(\d)\1{10}/', $cpf)) return false;

    // Primeiro dígito
    $soma = 0;
    for ($i = 0; $i < 9; $i++) $soma += intval($cpf[$i]) * (10 - $i);
    $resto = $soma % 11;
    $digito1 = ($resto < 2) ? 0 : 11 - $resto;
    if ($cpf[9] != $digito1) return false;

    // Segundo dígito
    $soma = 0;
    for ($i = 0; $i < 10; $i++) $soma += intval($cpf[$i]) * (11 - $i);
    $resto = $soma % 11;
    $digito2 = ($resto < 2) ? 0 : 11 - $resto;
    return $cpf[10] == $digito2;
}

// ------------------------------
// LÓGICA PRINCIPAL
// ------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // -------- CADASTRAR PROFESSOR --------
    if ($action === 'add') {
        // Validações
        if (empty($_POST['cpf']) || !validarCPF($_POST['cpf'])) {
            $error = "O CPF informado é inválido.";
        } elseif (empty($_POST['senha']) || strlen($_POST['senha']) < 8) {
            $error = "A senha é obrigatória e deve ter no mínimo 8 caracteres.";
        } elseif (!validarIdade($_POST['data_nascimento'], 18)) {
            $error = "O professor deve ter pelo menos 18 anos.";
        } elseif (strlen($_POST['rg']) <= 8 || strlen($_POST['rg']) > 9) {
            $error = "O RG deve ter 9 caracteres.";
        } else {
            // Verifica RG duplicado
            $sql_rg = "SELECT id FROM usuarios WHERE rg = ?";
            $stmt_rg = executar_consulta($conn, $sql_rg, [$_POST['rg']]);
            $existe_rg = $stmt_rg->get_result()->fetch_assoc();

            if ($existe_rg) {
                $error = "Já existe um usuário cadastrado com este RG.";
            } else {
                iniciar_transacao($conn);
                try {
                    // Inserir usuário
                    $hashedPassword = password_hash($_POST['senha'], PASSWORD_DEFAULT);
                    $sql_usuario = "
                        INSERT INTO usuarios 
                        (nome, email, senha, tipo, cpf, rg, cidade, endereco, complemento, data_nascimento, forcar_troca_senha)
                        VALUES (?, ?, ?, 'professor', ?, ?, ?, ?, ?, ?, 1)
                    ";
                    executar_consulta($conn, $sql_usuario, [
                        $_POST['nome'], $_POST['email'], $hashedPassword, $_POST['cpf'], $_POST['rg'],
                        $_POST['cidade'], $_POST['endereco'], $_POST['complemento'], $_POST['data_nascimento']
                    ]);

                    $usuario_id = $conn->insert_id;

                    // Inserir professor
                    $sql_professor = "
                        INSERT INTO professores 
                        (usuario_id, data_contratacao, formacao, instrumentos_leciona, valor_hora_aula, biografia)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ";
                    executar_consulta($conn, $sql_professor, [
                        $usuario_id, $_POST['data_contratacao'], $_POST['formacao'],
                        $_POST['instrumento'], $_POST['valor_hora_aula'], $_POST['biografia']
                    ]);

                    confirmar_transacao($conn);
                    $message = "Professor cadastrado com sucesso!";
                } catch (Exception $e) {
                    reverter_transacao($conn);
                    $error = "Erro ao cadastrar professor: " . $e->getMessage();
                }
            }
        }
    }

    // -------- EXCLUIR PROFESSOR --------
    elseif ($action === 'delete') {
        $usuario_id = $_POST['usuario_id'] ?? null;
        if ($usuario_id) {
            executar_consulta($conn, "DELETE FROM usuarios WHERE id = ?", [$usuario_id]);
            $message = "Professor excluído com sucesso!";
        } else {
            $error = "ID do usuário não fornecido para exclusão.";
        }
    }
}

// ------------------------------
// LISTAGEM DE PROFESSORES
// ------------------------------
$sql_listar = "
    SELECT 
        p.*, u.nome, u.email, u.created_at, u.ativo, u.cpf, u.rg,
        p.id AS professor_id, u.id AS usuario_id
    FROM professores p
    JOIN usuarios u ON p.usuario_id = u.id
    ORDER BY u.nome ASC
";
$resultado = $conn->query($sql_listar);
$professores = $resultado->fetch_all(MYSQLI_ASSOC);
?>

<!-- ---------------------- FORMULÁRIO ---------------------- -->
<div class="card">
    <h3>Cadastrar Novo Professor</h3>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" style="margin-bottom: 30px;">
        <input type="hidden" name="action" value="add">

        <!-- Dados Pessoais -->
        <div class="form-section">
            <h4>Dados Pessoais e de Acesso</h4>

            <div class="form-row">
                <div class="form-group">
                    <label>Nome Completo:</label>
                    <input type="text" name="nome" required value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Senha (mín. 8 caracteres):</label>
                <div style="display: flex; gap: 10px;">
                    <input type="password" id="senha" name="senha" required minlength="8" readonly placeholder="Clique em 'Gerar' para criar a senha" style="flex-grow: 1;">
                    <button type="button" id="btnGerarSenha" class="btn btn-secondary">Gerar</button>
                </div>
            </div>

            <div class="form-group">
                <label>Data de Nascimento:</label>
                <input type="text" id="data_nascimento" name="data_nascimento" required 
                       value="<?= htmlspecialchars($_POST['data_nascimento'] ?? date('Y-m-d')) ?>">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>CPF:</label>
                    <input type="text" id="cpf" name="cpf" maxlength="14" required value="<?= htmlspecialchars($_POST['cpf'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>RG:</label>
                    <input type="text" id="rg" name="rg" maxlength="9" value="<?= htmlspecialchars($_POST['rg'] ?? '') ?>">
                </div>
            </div>
        </div>

        <!-- Dados Profissionais -->
        <div class="form-section">
            <h4>Dados Profissionais e Musicais</h4>

            <div class="form-row">
                <div class="form-group">
                    <label>Formação Acadêmica:</label>
                    <input type="text" name="formacao" placeholder="Ex: Bacharel em Música" value="<?= htmlspecialchars($_POST['formacao'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Data da Contratação:</label>
                    <input type="text" id="data_contratacao" name="data_contratacao" required 
                           value="<?= htmlspecialchars($_POST['data_contratacao'] ?? date('Y-m-d')) ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Instrumento Principal:</label>
                    <select name="instrumento" required>
                        <?php
                        $instrumentos = ['Violão', 'Guitarra', 'Baixo', 'Teclado', 'Piano', 'Canto', 'Bateria', 'Violino', 'Outro'];
                        foreach ($instrumentos as $inst) {
                            $selected = ($_POST['instrumento'] ?? '') == $inst ? 'selected' : '';
                            echo "<option value='$inst' $selected>$inst</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Valor da Hora/Aula (R$):</label>
                    <input type="number" step="0.01" name="valor_hora_aula" placeholder="Ex: 75.50" 
                           value="<?= htmlspecialchars($_POST['valor_hora_aula'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Biografia (opcional):</label>
                <textarea name="biografia" rows="3"><?= htmlspecialchars($_POST['biografia'] ?? '') ?></textarea>
            </div>
        </div>

        <!-- Endereço -->
        <div class="form-section">
            <h4>Endereço</h4>

            <div class="form-row">
                <div class="form-group">
                    <label>Cidade:</label>
                    <input type="text" name="cidade" value="<?= htmlspecialchars($_POST['cidade'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Endereço:</label>
                    <input type="text" name="endereco" placeholder="Rua, número" value="<?= htmlspecialchars($_POST['endereco'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Complemento:</label>
                <input type="text" name="complemento" placeholder="Apto, bloco, etc." value="<?= htmlspecialchars($_POST['complemento'] ?? '') ?>">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Cadastrar Professor</button>
    </form>
</div>

<!-- ---------------------- LISTAGEM ---------------------- -->
<div class="card">
    <h3>Lista de Professores (<?= count($professores) ?>)</h3>

    <?php if (empty($professores)): ?>
        <div class="empty-state"><p>Nenhum professor cadastrado ainda.</p></div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table" id="tabelaProfessores">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Instrumento</th>
                        <th>Status</th>
                        <th>Cadastrado em</th>
                        <?php if (isAdmin()): ?><th>Ações</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($professores as $p): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($p['nome']) ?></strong></td>
                            <td><?= htmlspecialchars($p['email']) ?></td>
                            <td><?= htmlspecialchars($p['instrumentos_leciona'] ?? '-') ?></td>
                            <td>
                                <span class="status-badge <?= ($p['ativo'] ?? 1) ? 'status-realizado' : 'status-cancelado' ?>">
                                    <?= ($p['ativo'] ?? 1) ? 'Ativo' : 'Inativo' ?>
                                </span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($p['created_at'])) ?></td>
                            <?php if (isAdmin()): ?>
                                <td>
                                    <div class="user-info" style="text-align:center;">
                                        <a href="dashboard.php?page=editar-prof&professor_id=<?= htmlspecialchars($p['professor_id']) ?>" class="btn-link">Editar</a>
                                        <form method="POST" style="display:inline-block;" onsubmit="return confirm('Tem certeza que deseja apagar este professor?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="usuario_id" value="<?= htmlspecialchars($p['usuario_id']) ?>">
                                            <button type="submit" class="btn-delete">Apagar</button>
                                        </form>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>


<script>
// JavaScript não foi alterado.
document.getElementById('cpf').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    e.target.value = value;
});
</script>

<script>
    // 1. Pega os elementos que acabamos de criar no HTML
    const botaoGerar = document.getElementById('btnGerarSenha');
    const inputSenha = document.getElementById('senha');

    // 2. A sua função de gerar senha, "traduzida" para JavaScript
    function gerarSenhaJS(tamanho = 12) {
        const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const tamanhoStr = caracteres.length;
        let strAleatorio = '';

        // Em JS, usamos crypto.getRandomValues para segurança
        const randomValues = new Uint32Array(tamanho);
        window.crypto.getRandomValues(randomValues);

        for (let i = 0; i < tamanho; i++) {
            // Isso é o equivalente seguro de 'random_int'
            const index = randomValues[i] % tamanhoStr;
            strAleatorio += caracteres[index];
        }
        return strAleatorio;
    }

// 3. Adiciona o "ouvinte" de clique no botão
    botaoGerar.addEventListener('click', function() {
        // Quando o botão for clicado:
        // 1. Gera uma nova senha
        const novaSenha = gerarSenhaJS(8);
        
        // 2. Coloca a senha gerada no campo de input
        inputSenha.value = novaSenha;
        
        // 3. Muda o tipo para 'text' para o usuário ver a senha
        inputSenha.type = 'text';

        // 4. (NOVO) Desabilita o botão para que só possa ser gerada uma vez
        botaoGerar.disabled = true;
        botaoGerar.textContent = 'Gerada!'; // Muda o texto do botão
    });

    // (O listener de 'input' foi removido, pois o campo é readonly)
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // Configura o seletor de DATA (em Português)
    // O ID correto neste formulário é "data_contratacao"
    flatpickr("#data_contratacao", {
        locale: "pt", // Usa a tradução que carregamos
        dateFormat: "Y-m-d", // Formato que o banco de dados entende
        altInput: true, // Mostra um formato amigável para o usuário
        altFormat: "d/m/Y", // Formato amigável
        // Removemos a opção "minDate: 'today'" porque a data de contratação pode ser no passado.
    });
    flatpickr("#data_nascimento", {
        locale: "pt", // Usa a tradução que carregamos
        dateFormat: "Y-m-d", // Formato que o banco de dados entende
        altInput: true, // Mostra um formato amigável para o usuário
        altFormat: "d/m/Y", // Formato amigável
        // Removemos a opção "minDate: 'today'" porque a data de contratação pode ser no passado.
    });
    
});
</script>


<script>
// NOVO SCRIPT PARA DATATABLES
document.addEventListener('DOMContentLoaded', function() {
    // Usamos o jQuery, que foi carregado no dashboard.php
    if (typeof jQuery !== 'undefined') {
        jQuery(document).ready(function($) {
            $('#tabelaProfessores').DataTable({
                "language": {
                    // Arquivo de tradução oficial do DataTables para PT-BR
                    "url": "https://cdn.datatables.net/plug-ins/2.0.8/i18n/pt-BR.json" 
                }
            });
        });
    }
});
</script>



