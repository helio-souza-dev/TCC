<?php
require_once 'config/database.php';
require_once 'includes/auth.php'; // Pode ser necessário para verificar se o dev está logado

$database = new Database();
$message = '';
$error = '';
$user_to_edit = null;

// --- FUNÇÃO AUXILIAR ---
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $password = '';
    $characterCount = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $characterCount - 1)];
    }
    return $password;
}

// --- LÓGICA DE PROCESSAMENTO DE FORMULÁRIOS (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        // --- AÇÃO DE CRIAR USUÁRIO ---
        if ($action === 'create') {
            $email = trim($_POST['email'] ?? '');
            $nome = trim($_POST['nome'] ?? '');
            $tipo = $_POST['tipo'] ?? '';
            $senha = $_POST['senha'] ?? '';
            $matricula = trim($_POST['matricula'] ?? '');
            $turma = trim($_POST['turma'] ?? '');
            
            if (empty($email) || empty($nome) || empty($tipo)) {
                throw new Exception('Email, nome e tipo são obrigatórios.');
            }

            // Checa se o email já existe
            $stmt = $database->query("SELECT id FROM usuarios WHERE email = ?", [$email]);
            if ($stmt->fetch()) {
                throw new Exception('Usuário com este e-mail já existe.');
            }

            $password_to_use = $senha;
            $display_password = $senha;
            if (empty($senha)) {
                $password_to_use = generateRandomPassword(8);
                $display_password = $password_to_use;
            }
            $hashedPassword = password_hash($password_to_use, PASSWORD_DEFAULT);

            // Inicia a transação
            $database->beginTransaction();

            // Insere o usuário
            $sql_user = "INSERT INTO usuarios (email, nome, tipo, senha) VALUES (?, ?, ?, ?)";
            $database->query($sql_user, [$email, $nome, $tipo, $hashedPassword]);
            $userId = $database->getLastInsertId();
            
            // Se for aluno, insere na tabela de alunos
            if ($tipo === 'aluno') {
                if (empty($matricula)) {
                    $database->rollBack(); // Desfaz a criação do usuário
                    throw new Exception("Matrícula é obrigatória para alunos.");
                }
                $sql_aluno = "INSERT INTO alunos (usuario_id, matricula, turma) VALUES (?, ?, ?)";
                $database->query($sql_aluno, [$userId, $matricula, $turma]);
            }
            
            // Confirma a transação
            $database->commit();
            $message = "Usuário '$nome' ($tipo) criado. " . (!empty($display_password) ? "Senha: <strong>$display_password</strong>" : "");
        }

        // --- AÇÃO DE ATUALIZAR USUÁRIO ---
        if ($action === 'update') {
            $userId = $_POST['user_id'] ?? '';
            $email = trim($_POST['email'] ?? '');
            $nome = trim($_POST['nome'] ?? '');
            $tipo = $_POST['tipo'] ?? '';
            $senha = $_POST['senha'] ?? '';
            $matricula = trim($_POST['matricula'] ?? '');
            $turma = trim($_POST['turma'] ?? '');
            
            if (empty($userId) || empty($email) || empty($nome) || empty($tipo)) {
                throw new Exception('Faltam dados essenciais para a atualização.');
            }

            $database->beginTransaction();

            // Atualiza dados básicos do usuário
            $sql_user_update = "UPDATE usuarios SET email = ?, nome = ?, tipo = ? WHERE id = ?";
            $params_user = [$email, $nome, $tipo, $userId];
            $database->query($sql_user_update, $params_user);

            // Atualiza a senha se fornecida
            if (!empty($senha)) {
                $hashedPassword = password_hash($senha, PASSWORD_DEFAULT);
                $database->query("UPDATE usuarios SET senha = ? WHERE id = ?", [$hashedPassword, $userId]);
            }

            // Lógica para aluno
            $stmt_aluno = $database->query("SELECT id FROM alunos WHERE usuario_id = ?", [$userId]);
            $aluno_record_exists = $stmt_aluno->fetch();

            if ($tipo === 'aluno') {
                if (empty($matricula)) {
                    $database->rollBack();
                    throw new Exception("Matrícula é obrigatória para alunos.");
                }
                if ($aluno_record_exists) {
                    // Aluno já existe, então atualiza
                    $database->query("UPDATE alunos SET matricula = ?, turma = ? WHERE usuario_id = ?", [$matricula, $turma, $userId]);
                } else {
                    // Aluno não existe, então cria
                    $database->query("INSERT INTO alunos (usuario_id, matricula, turma) VALUES (?, ?, ?)", [$userId, $matricula, $turma]);
                }
            } else { // Se o tipo não for mais aluno
                if ($aluno_record_exists) {
                    // Apaga o registro de aluno
                    $database->query("DELETE FROM alunos WHERE usuario_id = ?", [$userId]);
                }
            }

            $database->commit();
            $message = "Usuário '$nome' atualizado com sucesso!";
            header('Location: dev_script.php');
            exit;
        }

        // --- AÇÃO DE APAGAR USUÁRIO ---
        if ($action === 'delete') {
            $userId = $_POST['user_id'] ?? '';
            if (empty($userId)) throw new Exception('ID do usuário não fornecido para exclusão.');

            // Graças ao ON DELETE CASCADE, só precisamos apagar da tabela de usuários.
            // O registro correspondente em 'alunos' será apagado automaticamente.
            $stmt = $database->query("DELETE FROM usuarios WHERE id = ?", [$userId]);
            if ($stmt->rowCount() > 0) {
                 $message = "Usuário apagado com sucesso.";
            } else {
                 throw new Exception("Usuário não encontrado para exclusão.");
            }
        }
    } catch (Exception $e) {
        $error = 'Erro: ' . $e->getMessage();
    }
}

// --- LÓGICA PARA PREPARAR EDIÇÃO (GET) ---
if (isset($_GET['edit_id'])) {
    $userId = $_GET['edit_id'];
    $sql_edit = "SELECT u.*, a.matricula, a.turma
                 FROM usuarios u
                 LEFT JOIN alunos a ON u.id = a.usuario_id
                 WHERE u.id = ?";
    $stmt = $database->query($sql_edit, [$userId]);
    $user_to_edit = $stmt->fetch();
    
    if (!$user_to_edit) {
        $error = "Usuário para edição não encontrado.";
    }
}

// --- BUSCAR TODOS OS USUÁRIOS PARA A LISTA ---
$sql_all = "SELECT u.id, u.nome, u.email, u.tipo, a.matricula
            FROM usuarios u
            LEFT JOIN alunos a ON u.id = a.usuario_id
            ORDER BY u.nome ASC";
$stmt_all = $database->query($sql_all);
$all_users = $stmt_all->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dev Tool: Gerenciar Usuários</title>
    <style>
        body { font-family: sans-serif; padding: 20px; line-height: 1.6; background-color: #f4f4f4; color: #333; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2, h3 { text-align: center; color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="password"], select { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #007bff; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; width: 100%; font-size: 16px; transition: background-color 0.2s; }
        button:hover { background-color: #0056b3; }
        button.btn-update { background-color: #28a745; }
        button.btn-update:hover { background-color: #218838; }
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .hidden-fields { display: none; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f8f9fa; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .actions a, .actions button { font-size: 12px; padding: 5px 10px; width: auto; display: inline-block; margin-right: 5px; }
        .actions button { background-color: #dc3545; }
        .actions button:hover { background-color: #c82333; }
        .actions a { background-color: #17a2b8; color: white; text-decoration: none; border-radius: 4px; }
        .actions a:hover { background-color: #138496; }
        small { color: #6c757d; }
    </style>
</head>
<body>
    <div class="container">
        <h2>🛠️ Ferramenta de Desenvolvimento</h2>

        <?php if ($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

        <h3><?php echo $user_to_edit ? '✏️ Editando Usuário' : '➕ Criar Novo Usuário'; ?></h3>
        <form action="dev_script.php" method="POST">
            <input type="hidden" name="action" value="<?php echo $user_to_edit ? 'update' : 'create'; ?>">
            <?php if ($user_to_edit): ?>
                <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_to_edit['id']); ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($user_to_edit['email'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required value="<?php echo htmlspecialchars($user_to_edit['nome'] ?? ''); ?>">
            </div>
             <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" placeholder="<?php echo $user_to_edit ? 'Deixe em branco para não alterar' : 'Deixe em branco para gerar senha aleatória'; ?>">
            </div>
            <div class="form-group">
                <label for="tipo">Tipo de Usuário:</label>
                <select id="tipo" name="tipo" required>
                    <option value="" <?php echo empty($user_to_edit['tipo']) ? 'selected' : ''; ?>>-- Selecione --</option>
                    <option value="aluno" <?php echo ($user_to_edit['tipo'] ?? '') === 'aluno' ? 'selected' : ''; ?>>Aluno</option>
                    <option value="professor" <?php echo ($user_to_edit['tipo'] ?? '') === 'professor' ? 'selected' : ''; ?>>Professor</option>
                    <option value="admin" <?php echo ($user_to_edit['tipo'] ?? '') === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                </select>
            </div>
            
            <div id="aluno-fields" class="hidden-fields">
                <div class="form-group">
                    <label for="matricula">Matrícula:</label>
                    <input type="text" id="matricula" name="matricula" value="<?php echo htmlspecialchars($user_to_edit['matricula'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="turma">Turma:</label>
                    <input type="text" id="turma" name="turma" value="<?php echo htmlspecialchars($user_to_edit['turma'] ?? ''); ?>">
                </div>
            </div>

            <button type="submit" class="<?php echo $user_to_edit ? 'btn-update' : ''; ?>"><?php echo $user_to_edit ? 'Atualizar Usuário' : 'Criar Usuário'; ?></button>
            <?php if ($user_to_edit): ?>
                <a href="dev_script.php" style="display: block; text-align: center; margin-top: 10px;">Cancelar Edição</a>
            <?php endif; ?>
        </form>

        <h3>👥 Usuários Existentes</h3>
        <?php if (empty($all_users)): ?>
            <p style="text-align:center;">Nenhum usuário encontrado.</p>
        <?php else: ?>
            <table>
                <thead><tr><th>Nome</th><th>Email</th><th>Tipo</th><th>Matrícula</th><th>Ações</th></tr></thead>
                <tbody>
                    <?php foreach ($all_users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['nome'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars(ucfirst($user['tipo'] ?? '')); ?></td>
                        <td><?php echo htmlspecialchars($user['matricula'] ?? 'N/A'); ?></td>
                        <td class="actions">
                            <a href="dev_script.php?edit_id=<?php echo $user['id']; ?>">Editar</a>
                            <form action="dev_script.php" method="POST" style="display:inline;" onsubmit="return confirm('Tem certeza que deseja apagar este usuário? Esta ação é irreversível.');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <button type="submit">Apagar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <script>
        function toggleAlunoFields() {
            var tipoSelect = document.getElementById('tipo');
            var alunoFields = document.getElementById('aluno-fields');
            var matriculaInput = document.getElementById('matricula');
            
            if (tipoSelect.value === 'aluno') {
                alunoFields.style.display = 'block';
                matriculaInput.setAttribute('required', 'required');
            } else {
                alunoFields.style.display = 'none';
                matriculaInput.removeAttribute('required');
            }
        }
        document.getElementById('tipo').addEventListener('change', toggleAlunoFields);
        window.addEventListener('DOMContentLoaded', toggleAlunoFields);
    </script>
</body>
</html>