<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();
$message = '';
$error = '';

// Função para gerar uma senha aleatória e segura
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%&*-_';
    $password = '';
    $characterCount = strlen($characters);
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $characterCount - 1)];
    }
    return $password;
}

// LÓGICA DE CADASTRO, EXCLUSÃO E EDIÇÃO
if($_POST && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Processa a ação de exclusão
    if ($action === 'delete') {
        if (isAdmin()) {
            $aluno_id = $_POST['aluno_id'] ?? null;
            $usuario_id = $_POST['usuario_id'] ?? null;

            if ($aluno_id && $usuario_id) {
                try {
                    $database->beginTransaction();
                    $database->query('DELETE FROM alunos WHERE id = ?', [$aluno_id]);
                    $database->query('DELETE FROM usuarios WHERE id = ?', [$usuario_id]);
                    $database->commit();
                    $message = 'Aluno e usuário associado apagados com sucesso!';
                } catch (Exception $e) {
                    if ($database->conn->inTransaction()) { $database->rollBack(); }
                    $error = 'Erro ao apagar aluno: ' . $e->getMessage();
                }
            } else {
                $error = 'ID do aluno ou usuário ausente.';
            }
        } else {
            $error = 'Você não tem permissão para realizar esta ação.';
        }
    } 
    // Processa a ação de cadastro de um novo aluno
    elseif ($action === 'add') {
        // Dados Pessoais
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $data_nascimento = trim($_POST['data_nascimento'] ?? '');
        $telefone = trim($_POST['telefone'] ?? '');
        $cpf = trim($_POST['cpf'] ?? null);
        $rg = trim($_POST['rg'] ?? null);

        // Dados do Responsável (para tabela alunos)
        $nome_responsavel = trim($_POST['nome_responsavel'] ?? null);
        $telefone_responsavel = trim($_POST['telefone_responsavel'] ?? null);

        // Novos campos da tabela alunos
        $instrumento = trim($_POST['instrumento'] ?? null);
        $nivel_experiencia = trim($_POST['nivel_experiencia'] ?? 'Iniciante');
        $tipo_aula_desejada = trim($_POST['tipo_aula_desejada'] ?? null);
        $preferencia_horario = trim($_POST['preferencia_horario'] ?? null);
        $possui_instrumento = isset($_POST['possui_instrumento']) ? (int)$_POST['possui_instrumento'] : null;
        $objetivos = trim($_POST['objetivos'] ?? null);


        if (empty($nome) || empty($email) || empty($data_nascimento)) {
            $error = 'Nome, email e data de nascimento são obrigatórios.';
        } else {
            $hoje = new DateTime();
            $nascimento = new DateTime($data_nascimento);
            $idade = $nascimento->diff($hoje)->y;
            
            if ($idade < 18 && empty($nome_responsavel)) {
                $error = 'Nome do responsável é obrigatório para menores de idade.';
            }

            if (empty($error)) {
                try {
                    $stmt = $database->query("SELECT id FROM usuarios WHERE email = ?", [$email]);
                    if ($stmt->fetch()) {
                        $error = 'Email já cadastrado.';
                    } else {
                        $randomPassword = generateRandomPassword();
                        $hashedPassword = password_hash($randomPassword, PASSWORD_DEFAULT);
                        $year = date('Y');
                        $stmt_matricula = $database->query("SELECT matricula FROM alunos WHERE matricula LIKE ? ORDER BY matricula DESC LIMIT 1", [$year . '%']);
                        $lastMatricula = $stmt_matricula->fetchColumn();
                        $matricula = $lastMatricula ? $year . str_pad((int)substr($lastMatricula, 4) + 1, 2, '0', STR_PAD_LEFT) : $year . '01';

                        $database->beginTransaction();

                        $sql_user = "INSERT INTO usuarios (nome, email, tipo, telefone, data_nascimento, cpf, rg, senha) VALUES (?, ?, 'aluno', ?, ?, ?, ?, ?)";
                        $database->query($sql_user, [$nome, $email, $telefone, $data_nascimento, $cpf, $rg, $hashedPassword]);
                        $userId = $database->getLastInsertId();

                        // **CORREÇÃO 2: Removido um '?' extra. Agora são 10 colunas e 10 '?'**
                        $sql_aluno = "INSERT INTO alunos (
                                        usuario_id, matricula, nome_responsavel, telefone_responsavel, 
                                        instrumento, nivel_experiencia, tipo_aula_desejada, preferencia_horario, 
                                        possui_instrumento, objetivos
                                      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; // Eram 11 '?'
                        $params_aluno = [
                            $userId, $matricula, $nome_responsavel, $telefone_responsavel, 
                            $instrumento, $nivel_experiencia, $tipo_aula_desejada, $preferencia_horario, 
                            $possui_instrumento, $objetivos
                        ];
                        $database->query($sql_aluno, $params_aluno);
                        
                        $database->commit();
                        
                        $message = 'Aluno cadastrado com sucesso! Matrícula: <strong>' . htmlspecialchars($matricula) . '</strong> | Senha: <strong>' . htmlspecialchars($randomPassword) . '</strong>';
                        $_POST = [];
                    }
                } catch (Exception $e) {
                    if ($database->conn->inTransaction()) { $database->rollBack(); }
                    $error = 'Erro ao cadastrar aluno: ' . $e->getMessage();
                }
            }
        }
    }
}


try {
   
    $sql_list = "
        SELECT 
            a.id, a.matricula,
            a.instrumento, a.nivel_experiencia, a.nome_responsavel, a.telefone_responsavel,
            u.id AS usuario_id, u.nome, u.email, u.data_nascimento, u.telefone, u.created_at
        FROM alunos a
        JOIN usuarios u ON a.usuario_id = u.id
        ORDER BY u.nome
    ";
    $stmt = $database->query($sql_list);
    $students = $stmt->fetchAll();
} catch (Exception $e) {
    $error = 'Erro ao listar alunos: ' . $e->getMessage();
    $students = [];
}
?>

<div class="card">
    <h3>Cadastrar Novo Aluno</h3>
    
    <?php if($message): ?>
        <div class="alert alert-success"> <?php echo $message; ?></div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert alert-error"> <?php echo $error; ?></div>
    <?php endif; ?>
    
    <form method="POST" style="margin-bottom: 30px;">
        <input type="hidden" name="action" value="add">
        
        <div class="form-section">
            <h4> Dados Pessoais</h4>
            <div class="form-row">
                <div class="form-group">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" id="nome" name="nome" required value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="CPF">CPF:</label>
                    <input type="text" id="cpf" name="cpf" required value="<?php echo htmlspecialchars($_POST['cpf'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="RG">RG:</label>
                    <input type="text" id="rg" name="rg" required value="<?php echo htmlspecialchars($_POST['rg'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="data_nascimento">Data de Nascimento:</label>
                    <input type="date" id="data_nascimento" name="data_nascimento" required value="<?php echo htmlspecialchars($_POST['data_nascimento'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="telefone">Telefone:</label>
                    <input type="text" id="telefone" name="telefone" placeholder="(00) 00000-0000" value="<?php echo htmlspecialchars($_POST['telefone'] ?? ''); ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h4> Dados Musicais</h4>
            <div class="form-row">
                <div class="form-group">
                    <label for="instrumento">Instrumento Principal:</label>
                    <input type="text" id="instrumento" name="instrumento" placeholder="Ex: Violão" value="<?php echo htmlspecialchars($_POST['instrumento'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="nivel_experiencia">Nível de Experiência:</label>

                    <select id="nivel_experiencia" name="nivel_experiencia">

                    <option value="Iniciante" <?php echo ($_POST['nivel_experiencia'] ?? '') == 'Iniciante' ? 'selected' : ''; ?>>Iniciante</option>

                    <option value="Básico" <?php echo ($_POST['nivel_experiencia'] ?? '') == 'Básico' ? 'selected' : ''; ?>>Básico</option>

                    <option value="Intermediário" <?php echo ($_POST['nivel_experiencia'] ?? '') == 'Intermediário' ? 'selected' : ''; ?>>Intermediário</option>

                    <option value="Avançado" <?php echo ($_POST['nivel_experiencia'] ?? '') == 'Avançado' ? 'selected' : ''; ?>>Avançado</option>

                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="tipo_aula_desejada">Tipo de Aula Desejada:</label>
                    <input type="text" id="tipo_aula_desejada" name="tipo_aula_desejada" placeholder="Ex: Aula em grupo, individual" value="<?php echo htmlspecialchars($_POST['tipo_aula_desejada'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="preferencia_horario">Preferência de Horário:</label>
                    <input type="text" id="preferencia_horario" name="preferencia_horario" placeholder="Ex: Manhã, Sábados" value="<?php echo htmlspecialchars($_POST['preferencia_horario'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Possui Instrumento Próprio?</label>
                    <div class="radio-group">

                        <label><input type="radio" name="possui_instrumento" value="1" <?php echo ($_POST['possui_instrumento'] ?? '') == '1' ? 'checked' : ''; ?>> Sim</label>

                        <label><input type="radio" name="possui_instrumento" value="0" <?php echo ($_POST['possui_instrumento'] ?? '') == '0' ? 'checked' : ''; ?>> Não</label>

                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group full-width">
                    <label for="objetivos">Objetivos com a Música:</label>
                    <textarea  style="  width: 100%;color: white; height: 150px; padding: 12px; box-sizing: border-box; border: 2px solid #8b7cc8; border-radius: 4px; background-color: #495057; id="objetivos" name="objetivos" rows="3" placeholder="Ex: Tocar como hobby, me profissionalizar..."><?php echo htmlspecialchars($_POST['objetivos'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>
        
        <div id="responsavel-fields" style="display: none;">
            <div class="form-section">

                <h4> Dados do Responsável (Obrigatório para menores de 18 anos)</h4>
               
                <div class="form-row">

                    <div class="form-group">
                        <label for="nome_responsavel">Nome Completo do Responsável:</label>

                <input type="text" id="nome_responsavel" name="nome_responsavel" value="<?php echo htmlspecialchars($_POST['nome_responsavel'] ?? ''); ?>">

                    </div>
                    <div class="form-group">

                        <label for="telefone_responsavel">Telefone do Responsável:</label>

                        <input type="text" id="telefone_responsavel" name="telefone_responsavel" value="<?php echo htmlspecialchars($_POST['telefone_responsavel'] ?? ''); ?>">
                    
                    </div>
                </div>
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">+ Cadastrar Aluno</button>
    </form>
</div>

<div class="card">
    <h3>Lista de Alunos (<?php echo count($students); ?>)</h3>
    
    <?php if(empty($students)): ?>
        <div class="empty-state"><p>Nenhum aluno cadastrado ainda.</p></div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th> Nome</th>
                        <th> Email</th>
                        <th> Matrícula</th>
                        <th> Instrumento</th>
                        <th> Nível</th>
                        <th> Responsável</th>
                        <th> Cadastrado</th>
                        <?php if (isAdmin()): ?>
                            <th>Ações</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($students as $student): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($student['nome'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></td>
                            <td><strong><?php echo htmlspecialchars($student['matricula']); ?></strong></td>
                            <td><?php echo htmlspecialchars($student['instrumento'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($student['nivel_experiencia'] ?? '-'); ?></td>
                            <td>
                                <?php if (!empty($student['nome_responsavel'])): ?>
                                    <strong><?php echo htmlspecialchars($student['nome_responsavel']); ?></strong>
                                    <?php if (!empty($student['telefone_responsavel'])): ?>
                                        <br><small> <?php echo htmlspecialchars($student['telefone_responsavel']); ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y', strtotime($student['created_at'])); ?></td>
                            <?php if (isAdmin()): ?>
                                <td>
                                    
                                    <button><a href="dashboard.php?page=editar-aluno&aluno_id=<?php echo htmlspecialchars($student['id']); ?>" class="btn_secundario">Editar</a></button>
                                        <form method="POST" style="display: inline-block;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="aluno_id" value="<?php echo htmlspecialchars($student['id']); ?>">
                                            <input type="hidden" name="usuario_id" value="<?php echo htmlspecialchars($student['usuario_id'] ?? ''); ?>">
                                            <button type="submit" style="" class="btn_secundario">Apagar</button>
                                        </form>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?> 
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const dataNascimentoInput = document.getElementById('data_nascimento');
    const responsavelFields = document.getElementById('responsavel-fields');
    const nomeResponsavelInput = document.getElementById('nome_responsavel');

    function checkAge() {
        if (!dataNascimentoInput.value) {
            responsavelFields.style.display = 'none';
            nomeResponsavelInput.removeAttribute('required');
            return;
        }

        const dataNasc = new Date(dataNascimentoInput.value);
        const hoje = new Date();
        let idade = hoje.getFullYear() - dataNasc.getFullYear();
        const m = hoje.getMonth() - dataNasc.getMonth();
        if (m < 0 || (m === 0 && hoje.getDate() < dataNasc.getDate())) {
            idade--;
        }

        if (idade < 18) {
            responsavelFields.style.display = 'block';
            nomeResponsavelInput.setAttribute('required', 'required');
        } else {
            responsavelFields.style.display = 'none';
            nomeResponsavelInput.removeAttribute('required');
        }
    }

    dataNascimentoInput.addEventListener('change', checkAge);
    checkAge(); // Executa ao carregar a página para o caso de o formulário ser recarregado com dados
    
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const form = this.closest('form');
            if (confirm('Tem certeza que deseja apagar este aluno? Esta ação é irreversível.')) {
                form.submit();
            }
        });
    });
});
</script>
<style>

   .form-group select {
  width: 100%;
  padding: 12px;
  border: 2px solid var(--color-purple);
  background-color: var(--color-gray-dark);
  color: var(--color-white);
  border-radius: 5px;
  font-size: 16px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  appearance: none; 
  cursor: pointer;
    }

 .form-group input[type="radio"] {
  appearance: none; 
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-purple);
  border-radius: 50%;
  background-color: var(--color-gray-dark);
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;
  vertical-align: middle;
  margin-right: 8px;
}
.form-group input[type="radio"]:checked {
  background-color: white;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.3);
}


    </style>