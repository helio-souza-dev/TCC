<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();
$message = '';
$error = '';

if($_POST && isset($_POST['action']) && $_POST['action'] === 'add') {
    // --- Dados para a tabela USUARIOS ---
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $cpf = trim($_POST['cpf'] ?? '');
    $rg = trim($_POST['rg'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $endereco = trim($_POST['endereco'] ?? '');
    $complemento = trim($_POST['complemento'] ?? '');
    
    // --- Dados para a tabela PROFESSORES ---
    $formacao = trim($_POST['formacao'] ?? '');
    $data_contratacao = trim($_POST['data_contratacao'] ?? '');
    $instrumentos_leciona = trim($_POST['instrumentos_leciona'] ?? '');
    $niveis_leciona = trim($_POST['niveis_leciona'] ?? '');
    $valor_hora_aula = trim($_POST['valor_hora_aula'] ?? '');

    if (empty($nome) || empty($email) || empty($senha) || empty($cpf)) {
        $error = 'Nome, email, senha e CPF são obrigatórios.';
    } elseif (strlen($senha) < 8) {
        $error = 'A senha deve ter no mínimo 8 caracteres.';
    } else {
        try {
            $stmt = $database->query("SELECT id FROM usuarios WHERE email = ? OR cpf = ?", [$email, $cpf]);
            if ($stmt->fetch()) {
                $error = 'Email ou CPF já cadastrado.';
            } else {
                $hashedPassword = password_hash($senha, PASSWORD_DEFAULT);
                $database->beginTransaction();
                
                // 1. Insere dados pessoais e de endereço em `usuarios`
                $sql_user = "INSERT INTO usuarios (nome, email, senha, tipo, cpf, rg, cidade, endereco, complemento) VALUES (?, ?, ?, 'professor', ?, ?, ?, ?, ?)";
                $database->query($sql_user, [$nome, $email, $hashedPassword, $cpf, $rg, $cidade, $endereco, $complemento]);
                $userId = $database->getLastInsertId();

                // 2. Insere dados profissionais em `professores`
                $sql_prof = "INSERT INTO professores (usuario_id, formacao, data_contratacao, instrumentos_leciona, niveis_leciona, valor_hora_aula) VALUES (?, ?, ?, ?, ?, ?)";
                $params_prof = [$userId, $formacao, $data_contratacao ?: null, $instrumentos_leciona, $niveis_leciona, empty($valor_hora_aula) ? null : $valor_hora_aula];
                $database->query($sql_prof, $params_prof);
                
                $database->commit();
                $message = 'Professor cadastrado com sucesso!';
                $_POST = [];
            }
        } catch (Exception $e) {
            if ($database->conn->inTransaction()) { $database->rollBack(); }
            $error = 'Erro ao cadastrar professor: ' . $e->getMessage();
        }
    }
}

// Lógica de listagem
try {
    $sql_list = "SELECT p.id, p.instrumentos_leciona, u.id as usuario_id, u.nome, u.email, u.ativo
                 FROM professores p
                 JOIN usuarios u ON p.usuario_id = u.id
                 WHERE u.tipo = 'professor'
                 ORDER BY u.nome";
    $stmt = $database->query($sql_list);
    $teachers = $stmt->fetchAll();
} catch (Exception $e) {
    $error = 'Erro ao listar professores: ' . $e->getMessage();
    $teachers = [];
}
?>

<div class="card">
    <h3> Cadastrar Novo Professor</h3>
    <?php if($message): ?><div class="alert alert-success"> <?php echo $message; ?></div><?php endif; ?>
    <?php if($error): ?><div class="alert alert-error"> <?php echo $error; ?></div><?php endif; ?>
    
    <form method="POST" style="margin-bottom: 30px;">
        <input type="hidden" name="action" value="add">
        
        <div class="form-section">
            <h4> Dados Pessoais e de Acesso</h4>
            <div class="form-row">
                <div class="form-group"><label for="nome">Nome Completo:</label><input type="text" id="nome" name="nome" required value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>"></div>
                <div class="form-group"><label for="email">Email:</label><input type="email" id="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"></div>
            </div>
             <div class="form-row">
                <div class="form-group"><label for="cpf">CPF:</label><input type="text" id="cpf" name="cpf" required maxlength="14" value="<?php echo htmlspecialchars($_POST['cpf'] ?? ''); ?>"></div>
                <div class="form-group"><label for="rg">RG:</label><input type="text" id="rg" name="rg" value="<?php echo htmlspecialchars($_POST['rg'] ?? ''); ?>"></div>
            </div>
             <div class="form-row">
                <div class="form-group"><label for="senha">Senha:</label><input type="password" id="senha" name="senha" required placeholder="Mínimo 8 caracteres"></div>
             </div>
        </div>

        <div class="form-section">
            <h4> Dados Profissionais e Musicais</h4>
            <div class="form-row">
                <div class="form-group"><label for="formacao">Formação Acadêmica:</label><input type="text" id="formacao" name="formacao" placeholder="Ex: Bacharel em Música" value="<?php echo htmlspecialchars($_POST['formacao'] ?? ''); ?>"></div>
                <div class="form-group"><label for="data_contratacao">Data de Contratação:</label><input type="date" id="data_contratacao" name="data_contratacao" value="<?php echo htmlspecialchars($_POST['data_contratacao'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label for="instrumentos_leciona">Instrumentos que Leciona:</label><input type="text" id="instrumentos_leciona" name="instrumentos_leciona" required placeholder="Ex: Violão, Guitarra, Baixo" value="<?php echo htmlspecialchars($_POST['instrumentos_leciona'] ?? ''); ?>"></div>
                <div class="form-group"><label for="niveis_leciona">Níveis que Leciona:</label><input type="text" id="niveis_leciona" name="niveis_leciona" placeholder="Ex: Iniciante, Avançado" value="<?php echo htmlspecialchars($_POST['niveis_leciona'] ?? ''); ?>"></div>
            </div>
             <div class="form-row">
                <div class="form-group"><label for="valor_hora_aula">Valor da Hora/Aula (R$):</label><input type="number" step="0.01" id="valor_hora_aula" name="valor_hora_aula" placeholder="Ex: 75.50" value="<?php echo htmlspecialchars($_POST['valor_hora_aula'] ?? ''); ?>"></div>
            </div>
        </div>

        <div class="form-section">
            <h4> Endereço</h4>
            <div class="form-row">
                <div class="form-group"><label for="cidade">Cidade:</label><input type="text" id="cidade" name="cidade" value="<?php echo htmlspecialchars($_POST['cidade'] ?? ''); ?>"></div>
                <div class="form-group"><label for="endereco">Endereço:</label><input type="text" id="endereco" name="endereco" placeholder="Rua, número" value="<?php echo htmlspecialchars($_POST['endereco'] ?? ''); ?>"></div>
            </div>
            <div class="form-group"><label for="complemento">Complemento:</label><input type="text" id="complemento" name="complemento" placeholder="Apto, bloco, etc." value="<?php echo htmlspecialchars($_POST['complemento'] ?? ''); ?>"></div>
        </div>

        <button type="submit" class="btn btn-primary"> Cadastrar Professor</button>
    </form>
</div>

<div class="card">
    <h3> Lista de Professores (<?php echo count($teachers); ?>)</h3>
    <?php if(empty($teachers)): ?>
        <div class="empty-state"> </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>CPF</th>
                    <th>RG</th>
                    <th>Instrumentos</th>
                    <th>Status</th>
                    <?php if (isAdmin()): ?><th>Ações</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach($teachers as $teacher): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($teacher['nome']); ?></strong></td>
                        <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                        <td><?php echo htmlspecialchars($teacher['rg'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($teacher['cpf'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($teacher['instrumentos_leciona'] ?? '-'); ?></td>
                        <td>
                            <span class="status <?php echo ($teacher['ativo'] ?? true) ? 'active' : 'inactive'; ?>">
                                <?php echo ($teacher['ativo'] ?? true) ? ' Ativo' : ' Inativo'; ?>
                            </span>
                        </td>
                        <?php if (isAdmin()): ?>
                            <td>
                                <a href="dashboard.php?page=editar-prof&professor_id=<?php echo htmlspecialchars($teacher['id']); ?>" class="btn_secundario">Editar</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('cpf').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    e.target.value = value;
});
</script>