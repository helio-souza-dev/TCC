<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();
$message = '';
$error = '';
$student = null;

// Garante que apenas administradores podem acessar esta página
if (!isAdmin()) {
    header('Location: dashboard.php');
    exit();
}

// Lógica de processamento de formulários (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // --- AÇÃO: ALTERAR SENHA ---
    if ($action === 'change_password') {
        $usuario_id = $_POST['usuario_id'] ?? null;
        $newPassword = $_POST['new_password'] ?? null;

        if ($usuario_id && $newPassword) {
            try {
                if (strlen($newPassword) < 6) {
                    throw new Exception('A nova senha deve ter no mínimo 6 caracteres.');
                }
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $sql = "UPDATE usuarios SET senha = ? WHERE id = ?";
                $database->query($sql, [$hashedPassword, $usuario_id]);
                $message = 'Senha alterada com sucesso!';
            } catch (Exception $e) {
                $error = 'Erro ao alterar a senha: ' . $e->getMessage();
            }
        } else {
            $error = 'ID do usuário ou nova senha ausente.';
        }
    }

    // --- AÇÃO: ATUALIZAR DADOS DO ALUNO ---
    elseif ($action === 'update') {
        $aluno_id = $_POST['aluno_id'] ?? null;
        $usuario_id = $_POST['usuario_id'] ?? null;

        // Dados para a tabela USUARIOS
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $data_nascimento = trim($_POST['data_nascimento'] ?? '');
        $telefone = trim($_POST['telefone'] ?? '');
        $cpf = trim($_POST['cpf'] ?? '');
        $rg = trim($_POST['rg'] ?? '');
        
        // Dados para a tabela ALUNOS
        $matricula = trim($_POST['matricula'] ?? '');
        $instrumento = trim($_POST['instrumento'] ?? '');
        $nivel_experiencia = $_POST['nivel_experiencia'] ?? 'Iniciante';
        $nome_responsavel = trim($_POST['nome_responsavel'] ?? null);
        $telefone_responsavel = trim($_POST['telefone_responsavel'] ?? null);

        if (empty($nome) || empty($email) || empty($matricula)) {
            $error = 'Nome, email e matrícula são obrigatórios.';
        } else {
            try {
                $database->beginTransaction();

                // 1. Atualiza a tabela `usuarios`
                $sql_user = "UPDATE usuarios SET nome = ?, email = ?, data_nascimento = ?, telefone = ?, cpf = ?, rg = ? WHERE id = ?";
                $database->query($sql_user, [$nome, $email, $data_nascimento, $telefone, $cpf, $rg, $usuario_id]);

                // 2. Atualiza a tabela `alunos`
                $sql_aluno = "UPDATE alunos SET matricula = ?, instrumento = ?, nivel_experiencia = ?, nome_responsavel = ?, telefone_responsavel = ? WHERE id = ?";
                $params_aluno = [$matricula, $instrumento, $nivel_experiencia, $nome_responsavel, $telefone_responsavel, $aluno_id];
                $database->query($sql_aluno, $params_aluno);
                
                $database->commit();
                $message = 'Dados do aluno atualizados com sucesso!';
            } catch (Exception $e) {
                if ($database->conn->inTransaction()) { $database->rollBack(); }
                $error = 'Erro ao atualizar dados: ' . $e->getMessage();
            }
        }
    }
}

// Carrega os dados do aluno para exibição no formulário (GET)
if (isset($_GET['aluno_id'])) {
    $aluno_id_get = $_GET['aluno_id'];
    try {
        $sql = "SELECT a.*, u.*, a.id AS aluno_id, u.id AS usuario_id
                FROM alunos a
                JOIN usuarios u ON a.usuario_id = u.id
                WHERE a.id = ? AND u.tipo = 'aluno'
                LIMIT 1";
        $stmt = $database->query($sql, [$aluno_id_get]);
        $student = $stmt->fetch();

        if (!$student) {
            $error = 'Aluno não encontrado ou o registro não é de um aluno.';
            $student = null;
        }
    } catch (Exception $e) {
        $error = 'Erro ao carregar dados do aluno: ' . $e->getMessage();
    }
} elseif(!$_POST) {
    $error = 'ID do aluno não fornecido.';
}
?>

<div class="card">
    <h3> Editar Aluno</h3>
    
    <?php if($message): ?><div class="alert alert-success"> <?php echo $message; ?></div><?php endif; ?>
    <?php if($error): ?><div class="alert alert-error"> <?php echo $error; ?></div><?php endif; ?>
    
    <?php if ($student): ?>
    
        <div class="form-section" style="margin-top: 30px;">
            <h2> Alterar Senha</h2>
            <form method="POST">
                <input type="hidden" name="action" value="change_password">
                <input type="hidden" name="usuario_id" value="<?php echo htmlspecialchars($student['usuario_id']); ?>">
                <div class="form-group">
                    <label for="new_password">Nova Senha (mínimo 6 caracteres):</label><br>
                    <input type="password" id="new_password" name="new_password" required minlength="6">
                </div>
                <button type="submit" class="btn btn-warning" onclick="return confirm('Tem certeza que deseja alterar a senha deste usuário?')">Salvar Nova Senha</button>
            </form>
        </div>

        <form method="POST">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="aluno_id" value="<?php echo htmlspecialchars($student['aluno_id']); ?>">
            <input type="hidden" name="usuario_id" value="<?php echo htmlspecialchars($student['usuario_id']); ?>">

            <div class="form-section">
               <br> <h3 style="text-align: center;"> Dados Pessoais</h3 > <br>
                <div class="form-row">
                    <div class="form-group"><label>Nome Completo:</label><input type="text" name="nome" required value="<?php echo htmlspecialchars($student['nome'] ?? ''); ?>"></div>
                    <div class="form-group"><label>Email:</label><input type="email" name="email" required value="<?php echo htmlspecialchars($student['email'] ?? ''); ?>"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>CPF:</label><input type="text" name="cpf" value="<?php echo htmlspecialchars($student['cpf'] ?? ''); ?>"></div>
                    <div class="form-group"><label>RG:</label><input type="text" name="rg" value="<?php echo htmlspecialchars($student['rg'] ?? ''); ?>"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Data de Nascimento:</label><input type="date" name="data_nascimento" required value="<?php echo htmlspecialchars($student['data_nascimento'] ?? ''); ?>"></div>
                    <div class="form-group"><label>Telefone:</label><input type="text" name="telefone" value="<?php echo htmlspecialchars($student['telefone'] ?? ''); ?>"></div>
                </div>
            </div>
            
            <div class="form-section">
                <br><h3 style="text-align: center;"> Dados Musicais e de Matrícula</h3><br>
                 <div class="form-row">
                    <div class="form-group"><label>Matrícula:</label><input type="text" name="matricula" required value="<?php echo htmlspecialchars($student['matricula'] ?? ''); ?>"></div>
                    <div class="form-group"><label>Instrumento:</label><input type="text" name="instrumento" required value="<?php echo htmlspecialchars($student['instrumento'] ?? ''); ?>"></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Nível:</label><select name="nivel_experiencia">
                        <option value="Iniciante" <?php echo ($student['nivel_experiencia'] == 'Iniciante') ? 'selected' : ''; ?>>Iniciante</option>
                        <option value="Básico" <?php echo ($student['nivel_experiencia'] == 'Básico') ? 'selected' : ''; ?>>Básico</option>
                        <option value="Intermediário" <?php echo ($student['nivel_experiencia'] == 'Intermediário') ? 'selected' : ''; ?>>Intermediário</option>
                        <option value="Avançado" <?php echo ($student['nivel_experiencia'] == 'Avançado') ? 'selected' : ''; ?>>Avançado</option>
                    </select></div>
                </div>
            </div>
 
              <br>  <h3 style="text-align: center;"> Dados do Responsável</h3> <br>
                <div class="form-row">
                    <div class="form-group"><label>Nome do Responsável:</label><input type="text" name="nome_responsavel" value="<?php echo htmlspecialchars($student['nome_responsavel'] ?? ''); ?>"></div>
                    <div class="form-group"><label>Telefone do Responsável:</label><input type="text" name="telefone_responsavel" value="<?php echo htmlspecialchars($student['telefone_responsavel'] ?? ''); ?>"></div>
                </div>
     
            
         
                <button type="submit" class="btn_secundario"> Salvar Alterações</button><br>
               <br> <a href="dashboard.php?page=alunos" class="btn_secundario">Cancelar</a>
            </div>
        </form>
    <?php endif; ?>
</div>

<script>
// O JavaScript para verificar a idade e mostrar os campos do responsável pode ser adicionado aqui, se necessário.
</script>

<script>
document.getElementById('data_nascimento').addEventListener('change', function() {
    const dataNasc = new Date(this.value);
    const hoje = new Date();
    let idade = hoje.getFullYear() - dataNasc.getFullYear();
    const m = hoje.getMonth() - dataNasc.getMonth();
    if (m < 0 || (m === 0 && hoje.getDate() < dataNasc.getDate())) {
        idade--;
    }
    const responsavelFields = document.getElementById('responsavel-fields');
    if (idade < 18) {
        responsavelFields.style.display = 'block';
    } else {
        responsavelFields.style.display = 'none';
        document.getElementById('nome_responsavel').value = '';
        document.getElementById('telefone_responsavel').value = '';
    }
});
window.addEventListener('load', function() {
    const dataNascInput = document.getElementById('data_nascimento');
    if (dataNascInput.value) {
        dataNascInput.dispatchEvent(new Event('change'));
    }
});
</script>
<style>

   .form-group select {
  width: 100%;
  padding: 12px;
  border: 2px solid var(--color-purple);
  background-color: var(--color-gray-dark);
  color: var(--color-white);
  border-radius: 5px;
  font-size: 16px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  appearance: none; 
  cursor: pointer;
    }

 .form-group input[type="radio"] {
  appearance: none; 
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-purple);
  border-radius: 50%;
  background-color: var(--color-gray-dark);
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;
  vertical-align: middle;
  margin-right: 8px;
}
.form-group input[type="radio"]:checked {
  background-color: white;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.3);
}


    </style>