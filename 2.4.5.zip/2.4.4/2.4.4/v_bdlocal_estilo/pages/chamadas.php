<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();
$message = '';
$error = '';

// Lógica de processamento de formulário foi MOVIDA para editar-aula.php

// Lógica para buscar as aulas usando SQL
$aulas = [];
try {
    $params = [];
    $where_clauses = [];
    $status_filter = $_GET['status'] ?? 'todos';

    if ($status_filter !== 'todos' && (isAdmin() || isProfessor())) {
        $where_clauses[] = "aa.status = ?";
        $params[] = $status_filter;
    }

    if (isAdmin()) 

    {
        $sql = "SELECT aa.*, u_aluno.nome as aluno_nome, al.matricula, u_prof.nome as professor_nome
                FROM aulas_agendadas aa
                LEFT JOIN alunos al ON aa.aluno_id = al.id
                LEFT JOIN usuarios u_aluno ON al.usuario_id = u_aluno.id
                LEFT JOIN professores p ON aa.professor_id = p.id
                LEFT JOIN usuarios u_prof ON p.usuario_id = u_prof.id";
    } 
    
    elseif (isProfessor()) 
    
    {
        $sql = "SELECT aa.*, u_aluno.nome as aluno_nome, al.matricula
                FROM aulas_agendadas aa
                LEFT JOIN alunos al ON aa.aluno_id = al.id
                LEFT JOIN usuarios u_aluno ON al.usuario_id = u_aluno.id";
        
        $stmt_prof_id = $database->query("SELECT id FROM professores WHERE usuario_id = ? LIMIT 1", [$_SESSION['user_id']]);
        $professor_id_correto = $stmt_prof_id->fetchColumn();
        if($professor_id_correto) {
             $where_clauses[] = "aa.professor_id = ?";
             $params[] = $professor_id_correto;
        } else {
            $where_clauses[] = "1 = 0";
        }
    } elseif (isAluno()) {
        $stmt_aluno_id = $database->query("SELECT id FROM alunos WHERE usuario_id = ? LIMIT 1", [$_SESSION['user_id']]);
        $aluno_id_correto = $stmt_aluno_id->fetchColumn();

        $sql = "SELECT aa.*, u_prof.nome as professor_nome
                FROM aulas_agendadas aa
                LEFT JOIN professores p ON aa.professor_id = p.id
                LEFT JOIN usuarios u_prof ON p.usuario_id = u_prof.id";
        
        if ($aluno_id_correto) {
            $where_clauses[] = "aa.aluno_id = ?";
            $params[] = $aluno_id_correto;
        } else {
            $where_clauses[] = "1 = 0"; 
        }
    }

    if (!empty($where_clauses)) {
        $sql .= " WHERE " . implode(" AND ", $where_clauses);
    }
    
    $sql .= " ORDER BY aa.data_aula DESC, aa.horario_inicio ASC";
    
    if (isset($sql)) {
        $stmt = $database->query($sql, $params);
        $aulas = $stmt->fetchAll();
    }
    
} catch (Exception $e) {
    $error = 'Erro ao carregar aulas: ' . $e->getMessage();
    $aulas = [];    
}
?>

<div class="card">
 
        <h3><?php echo isAluno() ? 'Minhas Aulas Agendadas' : 'Gerenciar Aulas e Frequência'; ?></h3>
        <?php if(isProfessor() || isAdmin()): ?>   
            
          

       
    
    
    <?php if(isset($_SESSION['message'])): ?>
        <div class="alert alert-success"> <?php echo htmlspecialchars($_SESSION['message']); unset($_SESSION['message']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-error"> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    
    <?php if(isProfessor() || isAdmin()): ?>
     

            <div class="form-group" style="margin-top: 50px;  margin-bottom: 30px; gap:20px ;display: flex; text-align: center;">
                 <a href="dashboard.php?page=nova-chamada" class="btn_secundario" >Agendar Nova Aula</a>
        <?php endif; ?>
                <a href="dashboard.php?page=chamadas&status=todos" class="btn_secundario <?php echo $status_filter === 'todos' ? '' : 'btn-outline'; ?>">Todos</a>

                <a href="dashboard.php?page=chamadas&status=agendado" class="btn_secundario <?php echo $status_filter === 'agendado' ? '' : 'btn-outline'; ?>">Agendados</a>

                <a href="dashboard.php?page=chamadas&status=realizado" class="btn_secundario <?php echo $status_filter === 'realizado' ? '' : 'btn-outline'; ?>">Realizados</a>

                <a href="dashboard.php?page=chamadas&status=cancelado" class="btn_secundario <?php echo $status_filter === 'cancelado' ? '' : 'btn-outline'; ?>">Cancelados</a>
                
     
</div>
        
        <?php if(empty($aulas)): ?>
            <div class="alert alert-info"><p> Nenhuma aula encontrada para o filtro selecionado.</p></div>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Data/Horário</th>
                        <th>Aluno</th>
                        <th>Disciplina</th>
                        <?php if(isAdmin()): ?><th>Professor</th><?php endif; ?>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($aulas as $aula): ?>
                        <tr>
                            <td><strong><?php echo date('d/m/Y', strtotime($aula['data_aula'])); ?></strong><br><small><?php echo date('H:i', strtotime($aula['horario_inicio'])); ?> - <?php echo date('H:i', strtotime($aula['horario_fim'])); ?></small></td>
                            <td><strong><?php echo htmlspecialchars($aula['aluno_nome'] ?? 'N/A'); ?></strong><br><small><?php echo htmlspecialchars($aula['matricula'] ?? 'N/A'); ?></small></td>
                            <td><?php echo htmlspecialchars($aula['disciplina'] ?? 'N/A'); ?></td>
                            <?php if(isAdmin()): ?><td><?php echo htmlspecialchars($aula['professor_nome'] ?? 'N/A'); ?></td><?php endif; ?>
                            <td>
                                <span class="status-badge status-<?php echo $aula['status']; ?>"><?php echo ucfirst($aula['status']); ?></span>
                                <?php if($aula['status'] === 'realizado'): ?>
                                    <br><small class="presenca-<?php echo $aula['presenca']; ?>"><?php echo 'Presença: ' . ucfirst($aula['presenca'] ?? 'N/A'); ?></small>
                                <?php elseif($aula['status'] === 'cancelado'): ?>
                                    <br><small class="presenca-justificada">(Justificada)</small>
                                    <?php if(!empty($aula['motivo_cancelamento'])): ?>
                                        <br><small style="color: #666;">Motivo: <?php echo htmlspecialchars($aula['motivo_cancelamento']); ?></small>
                                    <?php endif; ?>
                                <?php elseif($aula['status'] === 'agendado' && !empty($aula['motivo_reagendamento'])): ?>
                                    <br><small style="color: #1976d2;">Reagendada</small>
                                    <?php if(!empty($aula['data_reagendamento'])): ?>
                                        <br><small style="color: #999;">Em: <?php echo date('d/m/Y H:i', strtotime($aula['data_reagendamento'])); ?></small>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($aula['status'] === 'agendado'): ?>
                                    <a href="dashboard.php?page=editar_aula&id=<?php echo $aula['id']; ?>" class="btn_secundario"> Gerenciar</a>
                                <?php elseif($aula['status'] === 'realizado' || $aula['status'] === 'cancelado'): ?>
                                    <form method="POST" action="dashboard.php?page=editar_aula&id=<?php echo $aula['id']; ?>" style="display: inline;">
                                        <input type="hidden" name="action" value="reverter">
                                        <button type="submit" class="btn btn-outline btn-sm" onclick="return confirm('Reverter esta aula para o status Agendado?')">Reverter</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

    <?php elseif(isAluno()): ?>
        <table class="table">
            </table>
    <?php endif; ?>
</div>

