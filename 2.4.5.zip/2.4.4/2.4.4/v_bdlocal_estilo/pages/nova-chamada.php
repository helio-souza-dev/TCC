<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$database = new Database();

$message = '';
$error = '';

// Lógica de AGENDAMENTO quando o formulário é enviado
if($_POST && isset($_POST['action']) && $_POST['action'] === 'agendar_aula') {
    $aluno_id = $_POST['aluno_id'] ?? '';
    $disciplina = trim($_POST['disciplina'] ?? '');
    $data_aula = $_POST['data_aula'] ?? '';
    $horario_inicio = $_POST['horario_inicio'] ?? '';
    $horario_fim = $_POST['horario_fim'] ?? '';
    $observacoes = trim($_POST['observacoes'] ?? '');
    
    try {
        date_default_timezone_set('America/Sao_Paulo');

        // 1. Validações básicas de campos
        if (empty($aluno_id) || empty($disciplina) || empty($data_aula) || empty($horario_inicio) || empty($horario_fim)) {
            throw new Exception("Todos os campos obrigatórios devem ser preenchidos.");
        }
        
        // 2. Validações de data e hora
        $data_inicio_completa = new DateTime($data_aula . ' ' . $horario_inicio);
        $agora = new DateTime();
        if ($data_inicio_completa <= $agora) {
            throw new Exception("Não é possível agendar aulas no passado.");
        }
        
        $hora_inicio = new DateTime($horario_inicio);
        $hora_fim = new DateTime($horario_fim);
        if ($hora_fim <= $hora_inicio) {
            throw new Exception("O horário de término deve ser posterior ao horário de início.");
        }
        
        // 3. Define o professor_id com base no tipo de usuário
        $professor_id = null;
        if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin') {
            $professor_id = $_POST['professor_id'] ?? '';
            if (empty($professor_id)) {
                throw new Exception("Como administrador, você deve selecionar um professor.");
            }
        } else {
            // Assume que o usuário logado é um professor
            $stmt_prof = $database->query("SELECT id FROM professores WHERE usuario_id = ? LIMIT 1", [$_SESSION['user_id']]);
            $professor_id = $stmt_prof->fetchColumn();
            if (!$professor_id) {
                throw new Exception("ID do professor não encontrado para este usuário.");
            }
        }

        // 4. Verificação de conflito
        $sql_conflito = "
            SELECT id FROM aulas_agendadas
            WHERE professor_id = ? 
              AND data_aula = ? 
              AND status != 'cancelado'
              AND (? < horario_fim AND ? > horario_inicio)";
              
        $stmt_conflito = $database->query($sql_conflito, [
            $professor_id, 
            $data_aula, 
            $horario_inicio, 
            $horario_fim
        ]);

        if ($stmt_conflito->fetch()) {
            throw new Exception("Conflito de horário! Já existe uma aula para este professor neste período.");
        }
        
        // 5. Inserção no banco de dados
        $sql_insert = "
            INSERT INTO aulas_agendadas 
            (professor_id, aluno_id, disciplina, data_aula, horario_inicio, horario_fim, observacoes, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'agendado')
        ";
        
        $params = [
            $professor_id,
            $aluno_id,
            $disciplina,
            $data_aula,
            $horario_inicio,
            $horario_fim,
            !empty($observacoes) ? $observacoes : null
        ];
        
        $database->query($sql_insert, $params);
        
        $message = 'Aula agendada com sucesso!';
        $_POST = [];
        
    } catch(Exception $e) {
        $error = $e->getMessage();
        error_log("ERRO no agendamento: " . $error);
    }
}

// Buscar alunos e professores para preencher os selects do formulário
try {
    $sql_alunos = "SELECT a.id, a.matricula, u.nome 
                   FROM alunos a 
                   JOIN usuarios u ON a.usuario_id = u.id 
                   WHERE u.ativo = 1
                   ORDER BY u.nome ASC";
    $stmt_alunos = $database->query($sql_alunos);
    $students = $stmt_alunos->fetchAll();
    
    $sql_professores = "SELECT p.id, u.nome 
                        FROM professores p 
                        JOIN usuarios u ON p.usuario_id = u.id 
                        WHERE u.ativo = 1
                        ORDER BY u.nome ASC";
    $stmt_professores = $database->query($sql_professores);
    $professors = $stmt_professores->fetchAll();
    
} catch(Exception $e) {
    $students = [];
    $professors = [];
    if (empty($error)) {
        $error = 'Erro ao carregar listas: ' . $e->getMessage();
    }
}
?>

<div class="card">
    <h3>Agendar Nova Aula</h3>
    
    <?php if($message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <?php if($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <form method="POST" id="formAgendamento">
        <input type="hidden" name="action" value="agendar_aula">
        
        <div class="form-group">
            <label for="aluno_id">Selecionar Aluno: <span style="color: red;">*</span></label>
            <select id="aluno_id" name="aluno_id" required>
                <option value="">Escolha um aluno...</option>
                <?php foreach($students as $student): ?>
                    <option value="<?php echo htmlspecialchars($student['id']); ?>" <?php echo (isset($_POST['aluno_id']) && $_POST['aluno_id'] == $student['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($student['nome']); ?> - <?php echo htmlspecialchars($student['matricula'] ?? 'S/N'); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin'): ?>
            <div class="form-group">
                <label for="professor_id">Agendar para o Professor: <span style="color: red;">*</span></label>
                <select id="professor_id" name="professor_id" required>
                    <option value="">Escolha um professor...</option>
                    <?php foreach($professors as $prof): ?>
                        <option value="<?php echo htmlspecialchars($prof['id']); ?>" <?php echo (isset($_POST['professor_id']) && $_POST['professor_id'] == $prof['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($prof['nome']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>
            
        <div class="form-group">
            <label for="disciplina">Disciplina: <span style="color: red;">*</span></label>
            <input type="text" id="disciplina" name="disciplina" required 
                   value="<?php echo htmlspecialchars($_POST['disciplina'] ?? ''); ?>"
                   placeholder="Ex: Violão, Flauta">
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="data_aula">Data da Aula: <span style="color: red;">*</span></label>
                <input type="date" id="data_aula" name="data_aula" required 
                       value="<?php echo htmlspecialchars($_POST['data_aula'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="horario_inicio">Horário de Início: <span style="color: red;">*</span></label>
                <input type="time" id="horario_inicio" name="horario_inicio" required
                       value="<?php echo htmlspecialchars($_POST['horario_inicio'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="horario_fim">Horário de Término: <span style="color: red;">*</span></label>
                <input type="time" id="horario_fim" name="horario_fim" required
                       value="<?php echo htmlspecialchars($_POST['horario_fim'] ?? ''); ?>">
            </div>
        </div>
        
        <div class="form-group">
            <label for="observacoes">Observações (opcional):</label>
            <textarea id="observacoes" name="observacoes" rows="3" 
                      placeholder="Conteúdo da aula, materiais necessários, objetivos, etc."><?php echo htmlspecialchars($_POST['observacoes'] ?? ''); ?></textarea>
        </div>
        
        <div class="flex gap-10 mt-20">
            <button type="submit" class="btn">Agendar Aula</button><br>
          <br>  <a href="dashboard.php?page=chamadas" class="btn btn-outline">Voltar para Aulas</a>
        </div>
    </form>
</div>
<style>
   .form-group select {
  width: 100%;
  padding: 12px;
  border: 2px solid var(--color-purple);
  background-color: var(--color-gray-dark);
  color: var(--color-white);
  border-radius: 5px;
  font-size: 16px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  appearance: none; 
  cursor: pointer;
    }

 .form-group input[type="radio"] {
  appearance: none; 
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-purple);
  border-radius: 50%;
  background-color: var(--color-gray-dark);
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;
  vertical-align: middle;
  margin-right: 8px;
}
.form-group input[type="radio"]:checked {
  background-color: white;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.3);
}
textarea{

    color: white;
    width: 100%;
    height: 150px;
    padding: 12px;
    box-sizing: border-box;
    border: 2px solid #8b7cc8;
    border-radius: 4px; background-color: #495057;
           
}
.form-group input[type="checkbox"] {
  appearance: none; 
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-purple);
  border-radius: 50%;
  background-color: var(--color-gray-dark);
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;
  vertical-align: middle;
  margin-right: 8px;
}
.form-group input[type="checkbox"]:checked {
  background-color: white;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.3);
}


    </style>
