<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Apenas admin e professor podem acessar esta página
if (!isAdmin() && !isProfessor()) {
    header("Location: dashboard.php?page=chamadas");
    exit;
}

$database = new Database();
$aula_id = $_GET['id'] ?? null;
$aula = null;

if (!$aula_id) {
    $_SESSION['error'] = "ID da aula não fornecido.";
    header("Location: dashboard.php?page=chamadas");
    exit;
}

// Lógica de Processamento do Formulário (POST)
if ($_POST && isset($_POST['action'])) {
    try {
        $action = $_POST['action'];

        switch ($action) {
            case 'marcar_presenca':
                $database->query("UPDATE aulas_agendadas SET status = 'realizado', presenca = 'presente' WHERE id = ?", [$aula_id]);
                $_SESSION['message'] = 'Presença marcada com sucesso!';
                break;
            
            case 'marcar_falta':
                $database->query("UPDATE aulas_agendadas SET status = 'realizado', presenca = 'ausente' WHERE id = ?", [$aula_id]);
                $_SESSION['message'] = 'Falta registrada com sucesso!';
                break;

            case 'cancelar_aula':
                $motivo = trim($_POST['motivo_cancelamento'] ?? '');
                if (empty($motivo)) throw new Exception("O motivo do cancelamento é obrigatório.");
                
                $database->query("UPDATE aulas_agendadas SET status = 'cancelado', presenca = 'justificada', motivo_cancelamento = ?, data_cancelamento = NOW() WHERE id = ?", [$motivo, $aula_id]);
                $_SESSION['message'] = 'Aula cancelada e justificada com sucesso.';
                break;

            case 'reagendar_aula':
                $nova_data = $_POST['nova_data'] ?? '';
                $novo_horario_inicio = $_POST['novo_horario_inicio'] ?? '';
                $novo_horario_fim = $_POST['novo_horario_fim'] ?? '';
                $motivo_reagendamento = trim($_POST['motivo_reagendamento'] ?? '');

                if (empty($nova_data) || empty($novo_horario_inicio) || empty($novo_horario_fim)) throw new Exception("Nova data e horários são obrigatórios.");
                if (empty($motivo_reagendamento)) throw new Exception("O motivo do reagendamento é obrigatório.");
                
                $nova_datetime = $nova_data . ' ' . $novo_horario_inicio;
                if (strtotime($nova_datetime) <= time()) throw new Exception("Não é possível reagendar para uma data no passado.");

                $database->query(
                    "UPDATE aulas_agendadas SET status = 'agendado', presenca = NULL, data_aula = ?, horario_inicio = ?, horario_fim = ?, motivo_reagendamento = ?, data_reagendamento = NOW() WHERE id = ?",
                    [$nova_data, $novo_horario_inicio, $novo_horario_fim, $motivo_reagendamento, $aula_id]
                );
                $_SESSION['message'] = 'Aula reagendada com sucesso!';
                break;

            case 'reverter':
                $database->query("UPDATE aulas_agendadas SET status = 'agendado', presenca = NULL, motivo_cancelamento = NULL, motivo_reagendamento = NULL WHERE id = ?", [$aula_id]);
                $_SESSION['message'] = 'O status da aula foi revertido para "Agendado".';
                break;
        }

        header("Location: dashboard.php?page=chamadas");
        exit;

    } catch (Exception $e) {
        // Se der erro, permanece na página e exibe o erro
        $error = $e->getMessage();
    }
}


// Buscar dados da aula para exibir no formulário (GET)
try {
    $sql = "SELECT aa.*, u_aluno.nome as aluno_nome
            FROM aulas_agendadas aa
            JOIN alunos al ON aa.aluno_id = al.id
            JOIN usuarios u_aluno ON al.usuario_id = u_aluno.id
            WHERE aa.id = ? LIMIT 1";
    $stmt = $database->query($sql, [$aula_id]);
    $aula = $stmt->fetch();

    if (!$aula) {
        throw new Exception("Aula não encontrada.");
    }
} catch (Exception $e) {
    $_SESSION['error'] = "Erro ao carregar dados da aula: " . $e->getMessage();
    header("Location: dashboard.php?page=chamadas");
    exit;
}
?>

<div class="card">
  
        <h3>Gerenciar Aula</h3>
       
        <a href="dashboard.php?page=chamadas" class="btn_secundario">Voltar</a><br>
 

    <?php if (!empty($error)): ?>
        <div class="alert alert-error"> <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>


        <br>
        <p><strong>Aluno:</strong> <?php echo htmlspecialchars($aula['aluno_nome']); ?></p>
        <p><strong>Disciplina:</strong> <?php echo htmlspecialchars($aula['disciplina']); ?></p>
        <p><strong>Data Agendada:</strong> <?php echo date('d/m/Y', strtotime($aula['data_aula'])); ?> das <?php echo date('H:i', strtotime($aula['horario_inicio'])); ?> às <?php echo date('H:i', strtotime($aula['horario_fim'])); ?></p>
        <p><strong>Status Atual:</strong> <span class="status-badge status-<?php echo $aula['status']; ?>"><?php echo ucfirst($aula['status']); ?></span></p>
        
        <h3 style="text-align: center;">Ações de Frequência</h3>
        
        <br>

        
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="marcar_presenca">
             <button type="submit" class="btn"> Marcar Presença</button>
    </form><br>
  <br> 
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="marcar_falta">
                <button type="submit" class="btn btn-danger"> Marcar Falta</button>
            </form><br>
            <br>
      


        <h3 style="text-align: center;">Reagendar Aula</h3>
        <form method="POST">
            <input type="hidden" name="action" value="reagendar_aula">
            <div class="form-row">
                <div class="form-group">
                    <label for="nova_data">Nova Data:</label>
                    <input type="date" name="nova_data" id="nova_data" value="<?php echo htmlspecialchars($aula['data_aula']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="novo_horario_inicio">Novo Início:</label>
                    <input type="time" name="novo_horario_inicio" id="novo_horario_inicio" value="<?php echo htmlspecialchars($aula['horario_inicio']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="novo_horario_fim">Novo Fim:</label>
                    <input type="time" name="novo_horario_fim" id="novo_horario_fim" value="<?php echo htmlspecialchars($aula['horario_fim']); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="motivo_reagendamento">Motivo do Reagendamento:</label><br>
                <textarea style=" color: white; width: 100%; height: 150px; padding: 12px; box-sizing: border-box; border: 2px solid #8b7cc8; border-radius: 4px; background-color: #495057; " name="motivo_reagendamento" id="motivo_reagendamento" rows="3" required placeholder="Ex: Pedido do aluno, imprevisto, etc."></textarea>
            </div>
            <button type="submit" class="btn"> Reagendar</button>
        </form><br>
    
    
    <div>
        <h3 style="text-align: center;">Cancelar Aula (com justificativa)</h3>
        
        <form method="POST" onsubmit="return confirm('Tem certeza que deseja cancelar esta aula? Esta ação não pode ser desfeita facilmente.');">
            <input type="hidden" name="action" value="cancelar_aula">
            <div class="form-group">
                <label for="motivo_cancelamento">Motivo do Cancelamento:</label>
                <textarea style=" color: white; width: 100%; height: 150px; padding: 12px; box-sizing: border-box; border: 2px solid #8b7cc8; border-radius: 4px; background-color: #495057; " name="motivo_cancelamento" id="motivo_cancelamento" rows="3" required placeholder="Descreva o motivo obrigatório para o cancelamento."></textarea>
            </div>
            <button type="submit" class="btn btn-danger"> Cancelar Aula Permanentemente</button>
        </form>
    </div>
</div>

<style>

   .form-group select {
  width: 100%;
  padding: 12px;
  border: 2px solid var(--color-purple);
  background-color: var(--color-gray-dark);
  color: var(--color-white);
  border-radius: 5px;
  font-size: 16px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  appearance: none; 
  cursor: pointer;
    }

 .form-group input[type="radio"] {
  appearance: none; 
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-purple);
  border-radius: 50%;
  background-color: var(--color-gray-dark);
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;
  vertical-align: middle;
  margin-right: 8px;
}
.form-group input[type="radio"]:checked {
  background-color: white;
  box-shadow: 0 0 0 3px rgba(107, 70, 193, 0.3);
}


    </style>