-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 22/09/2025 às 16:27
-- Versão do servidor: 8.0.42
-- Versão do PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc_local`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `alunos`
--

DROP TABLE IF EXISTS `alunos`;
CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `matricula` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nome_responsavel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `telefone_responsavel` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `instrumento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nivel_experiencia` enum('Iniciante','Básico','Intermediário','Avançado') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Iniciante',
  `tipo_aula_desejada` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `preferencia_horario` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `possui_instrumento` tinyint(1) DEFAULT NULL,
  `objetivos` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricula` (`matricula`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `alunos`
--

INSERT INTO `alunos` (`id`, `usuario_id`, `matricula`, `nome_responsavel`, `telefone_responsavel`, `instrumento`, `nivel_experiencia`, `tipo_aula_desejada`, `preferencia_horario`, `possui_instrumento`, `objetivos`) VALUES
(4, 10, '202501', '', '', 'Violao', 'Iniciante', 'violao', 'manha', 0, 'dwasdwads');

-- --------------------------------------------------------

--
-- Estrutura para tabela `aulas_agendadas`
--

DROP TABLE IF EXISTS `aulas_agendadas`;
CREATE TABLE IF NOT EXISTS `aulas_agendadas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `professor_id` int DEFAULT NULL,
  `aluno_id` int DEFAULT NULL,
  `disciplina` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `data_aula` date NOT NULL,
  `horario_inicio` time NOT NULL,
  `horario_fim` time NOT NULL,
  `status` enum('agendado','realizado','cancelado') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'agendado',
  `presenca` enum('presente','ausente','justificada') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Status de presença do aluno na aula',
  `observacoes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `data_cancelamento` datetime DEFAULT NULL,
  `motivo_cancelamento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `motivo_reagendamento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_criacao` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `professor_id` (`professor_id`),
  KEY `aluno_id` (`aluno_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `professores`
--

DROP TABLE IF EXISTS `professores`;
CREATE TABLE IF NOT EXISTS `professores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL,
  `data_contratacao` date DEFAULT NULL,
  `formacao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `instrumentos_leciona` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `niveis_leciona` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `generos_especialidade` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `horarios_disponiveis` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `biografia` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `valor_hora_aula` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `professores`
--

INSERT INTO `professores` (`id`, `usuario_id`, `data_contratacao`, `formacao`, `instrumentos_leciona`, `niveis_leciona`, `generos_especialidade`, `horarios_disponiveis`, `biografia`, `valor_hora_aula`) VALUES
(4, 11, '2001-09-10', 'prof', 'violao', 'avançado', NULL, NULL, NULL, 50.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tipo` enum('aluno','professor','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cpf` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rg` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `telefone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cidade` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `endereco` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `complemento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `cpf` (`cpf`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `tipo`, `cpf`, `rg`, `data_nascimento`, `telefone`, `cidade`, `endereco`, `ativo`, `created_at`, `complemento`) VALUES
(1, 'Administrador', 'admin@admin.com', '$2y$10$3H.v2.yE4Y.V2QxV3e5yCeJtcaWGYzhG01.G55M0rp9fFL.dGk3/W', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-09-10 01:58:05', NULL),
(2, 'CLEDISON COSTA ALVES', 'heliosol777@gmail.com', '$2y$10$ixYJErYdEC3g6U5ngk02JO.I8jbDINR3z0LxTFPxZlXZTFE6vZ2Dm', 'professor', '277.966.738-92', NULL, NULL, NULL, NULL, NULL, 1, '2025-09-10 02:14:52', NULL),
(3, 'CLEDISON COSTA ALVES', 'heliosol377@gmail.com', '$2y$10$cAkynstJGrgF/bBVlwRp8u0ET8lWGVjMUA9LP79YyQiWYLZoZMMTa', 'professor', '279.667.389-23', NULL, NULL, NULL, NULL, NULL, 1, '2025-09-10 02:17:34', NULL),
(4, 'admin', 'admin@sistema.com', '$2y$10$DcbQ/S6ky.Nf/fuu0a06.OLAzjR8NF5z8daa6O7sBu78mIhgA6jXO', 'admin', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-09-11 00:14:36', NULL),
(6, 'a', 'aluno@gmail.com', '$2y$10$B2NxpwTUwzDJi2QIxNvKX.auZcNVYErcJkhBET0ZCI8RXn/9ehPTy', 'aluno', '123456789', '12345678', '2000-09-10', '1198816200000', NULL, NULL, 1, '2025-09-11 01:14:41', NULL),
(7, 'menor123', 'menor123@gmail.com', '$2y$10$3ZjsStS6FvMd1g0DKcBrIuayF4okzoKd2.pI9n/W65iSRNI0xygze', 'aluno', '123456787', '1234545', '2010-01-10', '11974328234', NULL, NULL, 1, '2025-09-11 01:16:19', NULL),
(8, 'CLEDISON COSTA ALVES', 'heliosol772@gmail.com', '$2y$10$9rxrWmzTEG/HFA6jtZcMJ.S2.vSQP/SVMRq8spHiPUA817Mf80B/K', 'aluno', '453.219.708-23', '6053033232', '2002-02-05', '11967226018', NULL, NULL, 1, '2025-09-19 23:51:03', NULL),
(9, 'Helio De Souza Costa', 'heliosol7734@gmail.com', '$2y$10$QlG0iPwoCIGCM13lh5/ylO5lGTcbZ7eSytFpNG5Y3FvfD7jyRI/Ji', 'professor', '769.088.605-15', '6053033232', NULL, NULL, 'Poa', 'Rua Marabá 141', 1, '2025-09-19 23:56:54', 'a2'),
(10, 'aluno_teste', 'aluno@sistema.com', '$2y$10$D1mUBjmuUxUPuXcEH.81Q.t6vD.DVsK0EbvyXl6wPBfELyWaGYSES', 'aluno', '45321970823', '123346789', '2001-09-10', '11988162072', NULL, NULL, 1, '2025-09-22 16:06:03', NULL),
(11, 'professor_teste', 'prof@sistema.com', '$2y$10$5/hKoVXjTfe/jCM9grsnYOAUqjn7CXV9kFi5il6v/rz5pBzFsQtB6', 'professor', '453.213.707-24', '1234563283', NULL, NULL, 'poa', 'rua', 1, '2025-09-22 16:07:57', 'a73');

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `fk_aluno_usuario_novo` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `aulas_agendadas`
--
ALTER TABLE `aulas_agendadas`
  ADD CONSTRAINT `fk_aula_aluno_novo` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_aula_professor_novo` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Restrições para tabelas `professores`
--
ALTER TABLE `professores`
  ADD CONSTRAINT `fk_professor_usuario_novo` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
