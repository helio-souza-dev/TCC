<?php
// Verifica se a constante BASE_URL já não foi definida antes de defini-la.
if (!defined('BASE_URL')) {
    define('BASE_URL', 'http://localhost/v_bdlocal');
}