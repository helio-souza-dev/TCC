<?php
// Define a URL base do seu projeto local
define('BASE_URL', '/tcc2/'); // Ajuste se o seu projeto estiver em outra pasta

// --- Configurações do Banco de Dados Local ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'tcc_local'); // O nome do banco que você criou
define('DB_USER', 'root');       // Usuário padrão do XAMPP/WAMP
define('DB_PASS', '');           // Senha padrão do XAMPP/WAMP (geralmente vazia)

class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $pdo;
    public $conn;

    public function __construct() {
        $this->conn = null;
        try {
            $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->db_name . ';charset=utf8mb4';
            $this->pdo = new PDO($dsn, $this->username, $this->password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn = $this->pdo;
        } catch (PDOException $e) {
            // Em um ambiente de produção, não exiba o erro detalhado.
            die('Erro de conexão: ' . $e->getMessage());
        }
    }

    /**
     * Método genérico para executar consultas.
     * @param string $sql A consulta SQL.
     * @param array $params Os parâmetros para a consulta preparada.
     * @return PDOStatement O objeto PDOStatement.
     */
    public function query($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            // Log do erro em um ambiente real
            error_log('Erro de Query: ' . $e->getMessage());
            // Para simplificar, estamos exibindo o erro, mas não faça isso em produção.
            throw new Exception('Erro ao executar a consulta: ' . $e->getMessage());
        }
    }

    /**
     * Retorna o ID do último registro inserido.
     */
    public function getLastInsertId() {
        return $this->pdo->lastInsertId();
    }
    
    /**
     * Inicia uma transação.
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }

    /**
     * Confirma uma transação.
     */
    public function commit() {
        return $this->pdo->commit();
    }

    /**
     * Reverte uma transação.
     */
    public function rollBack() {
        return $this->pdo->rollBack();
    }
}