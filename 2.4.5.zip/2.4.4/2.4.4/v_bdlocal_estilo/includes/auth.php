<?php
session_start();
// O __DIR__ garante que o caminho está sempre correto
require_once __DIR__ . '/../config/database.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';
}

function isProfessor() {
    return isLoggedIn() && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'professor';
}

function isAluno() {
    return isLoggedIn() && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'aluno';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php'); // Ajuste o caminho se necessário
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: dashboard.php');
        exit();
    }
}

function login($email, $senha) {
    $database = new Database();
    
    try {
        $sql = "SELECT id, nome, email, senha, tipo FROM usuarios WHERE email = ? LIMIT 1";
        $stmt = $database->query($sql, [$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($senha, $user['senha'])) {
            // Login bem-sucedido
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nome'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_type'] = $user['tipo'];
            
            error_log("[LOGIN] Login realizado com sucesso: " . $email . " (" . $user['tipo'] . ")");
            return true;
        }

        error_log("[LOGIN] Email ou senha incorretos para: " . $email);
        return false;

    } catch (Exception $e) {
        error_log("[LOGIN] Exceção: " . $e->getMessage());
        return false;
    }
}

function logout() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    header('Location: login.php'); // Ajuste o caminho se necessário
    exit();
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return [
        'id' => $_SESSION['user_id'],
        'nome' => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'tipo' => $_SESSION['user_type']
    ];
}